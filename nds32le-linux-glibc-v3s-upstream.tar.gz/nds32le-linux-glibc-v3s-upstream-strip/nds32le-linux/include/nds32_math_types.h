#ifndef __NDS32_MATH_TYPES_H__
#define __NDS32_MATH_TYPES_H__
/***************************************************************************
 * Copyright (C) 2012-2018 Andes Technology Corporation                    *
 * All rights reserved.                                                    *
 ***************************************************************************/
#ifdef  __cplusplus
extern "C"
{
#endif

#include "nds_math_types.h"

#ifdef  __cplusplus
}
#endif
#endif // NDS32_MATH_TYPES_H
